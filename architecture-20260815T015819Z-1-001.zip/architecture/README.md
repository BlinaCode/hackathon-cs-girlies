# Architecture Overview

## Purpose
This document is the fast orientation guide for engineers and AI agents working in this repository. It explains the system boundaries, the layered architecture, and the operational rules required to modify the Aura Chocolaterie code safely.

It is intentionally practical: where components live, how logic is split, how to run/test locally, and which failure modes are most common.

## System Context

```text
Web Browser (Mobile/Desktop)
              |
              v
     [HTML Document Object Model]
              |
        +-----+-----+
        |           |
        v           v
  [Vanilla JS]  [Vanilla CSS]
        |
        v
 [LocalStorage] (State Persistence)

External APIs: NONE
Build Processes/Bundlers: NONE
Backend/Databases: NONE (Static Frontend)
```

The system is a fully static, client-side web application by design.

---

## Core Design Decisions

### Decision 1: Vanilla Stack (HTML/CSS/JS)
Context: The project requires a lightweight, fast, and fully accessible frontend without the overhead of heavy frameworks.
Decision: Use Vanilla HTML5, CSS3, and ES6+ JavaScript. No React, no Vue, no Tailwind.
Rationale: This keeps setup nonexistent, ensures deep understanding of native web APIs, and prevents dependency bloat.
Consequences: All state management and DOM manipulation must be handled manually, requiring strict separation of concerns.

### Decision 2: Model-View-Controller (MVC) Architecture
Context: The codebase needs to be structured to support future integration with a backend database without breaking the UI.
Decision: Separate JavaScript logic into three strict layers:
- **Modelo (Entities):** Pure classes that define the data structure of business objects (e.g., `Producto`, `ItemCarrito`). They have no knowledge of the DOM or UI.
- **Vista (Visual Interfaces):** Files responsible for injecting HTML and updating the DOM. They receive data and display it; they contain no business logic.
- **Controlador (Controllers):** Files that mediate between user interactions, Models, and Views. They listen for user events, update Models, and command Views to re-render.
Rationale: This separation allows swapping the data source (e.g., from hardcoded arrays to a REST API) without touching the Views.
Consequences: Inter-module communication must use native DOM `CustomEvents` instead of global `window` functions.

### Decision 3: Mobile-First CSS with Custom Properties
Context: E-commerce traffic is predominantly mobile, and brand colors must be perfectly consistent.
Decision: Use `min-width` media queries for responsive design and CSS variables (`:root`) for all theme tokens.
Rationale: Scales easily from mobile to desktop. CSS variables allow for a single source of truth for the Aura brand identity.
Consequences: CSS modules must be structured logically, avoiding fixed pixel widths that break on smaller screens.

### Decision 4: sessionStorage for Cart State Persistence
Context: Users need a shopping cart that persists across page navigations within the same browser session.
Decision: Use browser `sessionStorage` as the persistence layer for cart state.
Rationale: Ensures the cart survives page navigations and refreshes within the session.
Consequences: `ControladorCarrito` is exclusively responsible for serializing/deserializing cart state; Views never touch storage directly.

---

## Directory Structure

```text
IHC-DesarrolloWebChocolateria/
├── *.html                        # HTML pages (index, tienda, contacto, etc.)
├── *.css                         # Modular CSS (cart.css, footer.css, etc.)
├── js/
│   ├── app.js                    # Entry point: initializes MVC modules per page
│   ├── modelo/
│   │   ├── Producto.js           # Entity: defines what a Product IS
│   │   └── ItemCarrito.js        # Entity: defines a cart item (product + quantity)
│   ├── vista/
│   │   ├── VistaCarrito.js       # Visual interface for the cart panel
│   │   ├── VistaComparador.js    # Visual interface for the product comparator
│   │   └── VistaModalProducto.js # Visual interface for the product detail modal
│   └── controlador/
│       ├── ControladorCarrito.js     # Manages cart interactions and state
│       ├── ControladorComparador.js  # Manages comparator interactions
│       ├── ControladorTienda.js      # Manages store filters and catalog
│       └── ControladorModal.js       # Manages when/what to show in the modal
├── Proyecto/
│   └── assets/                   # Images, icons, and static media
└── docs/
    ├── architecture/             # Architecture reference and guides
    ├── ai_development/           # AI agent definitions and workflows
    ├── product-requirements.md   # Product scope and user outcomes
    └── technical-requirements.md # Technical implementation constraints
```

Key principles:
- Separation of concerns: HTML is for structure, CSS is for presentation, JS is for logic.
- Modular code: CSS and JS are split by feature (e.g., `cart.css`, `cart.js`).

---

## Data Flow (e.g., Shopping Cart)

```text
Client clicks "Añadir al Carrito" (Vista / HTML button)
    |
    v
ControladorTienda reads data-* attributes from the <article>
    |
    v
ControladorTienda creates a new Producto entity
    |
    v
ControladorTienda dispatches CustomEvent('cart:agregar', { detail: producto })
    |
    v
ControladorCarrito receives the event
    |
    v
ControladorCarrito updates the ItemCarrito[] state array
    |
    v
ControladorCarrito persists to sessionStorage
    |
    v
ControladorCarrito calls VistaCarrito.render(items, total)
    |
    v
VistaCarrito updates the DOM (panel + badge)
```

Rules in flow:
- The DOM is NEVER the source of truth for state. State lives in the Controller (in-memory array).
- Models (Producto, ItemCarrito) know nothing about the DOM.
- Views know nothing about sessionStorage or business logic.
- Controllers are the only layer that touches both Models and Views.

---

## Development Environment

Prerequisites:
- A modern web browser.
- A local static web server (e.g., VS Code Live Server, `python -m http.server 8000`).

Primary setup:
1. Open the project folder in your editor.
2. Start your local static server.
3. Open `index.html` in your browser.

---

## Common Pitfalls

### Pitfall 1: Inline Styles or Events
Problem: Using `style="..."` or `onclick="..."` directly in HTML.
Solution: Move all styles to CSS classes and all events to `addEventListener` in JS.

### Pitfall 2: Desktop-Only Design
Problem: Using fixed widths (e.g., `width: 1200px`) causing horizontal scrolling on mobile.
Solution: Design for mobile first, use `max-width`, percentages, or `clamp()`, and use `min-width` media queries.

### Pitfall 3: State Desynchronization
Problem: Updating the cart UI without saving to `localStorage`, causing items to disappear on refresh.
Solution: Always persist state to `localStorage` immediately after mutating the JS object, then re-render.

### Pitfall 4: Accessibility Ignorance
Problem: Removing focus outlines (`outline: none`) or using `<div>` for buttons.
Solution: Use semantic tags (`<button>`) and ensure `:focus-visible` states are clearly styled.
